@extends('layouts.master')
@section('content')

<div class="row">
<section class="content">

    <!-- Default box -->
    <div class="box">

         <iframe src="http://uneleap.com/Any%20day%20now.htm"  height='1024px' width='100%' style="border:none;"> </iframe>
    </div>

</section>
</div>
@endsection