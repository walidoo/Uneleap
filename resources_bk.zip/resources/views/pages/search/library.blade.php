    <div class="row">
        <div class="col-md-9">
            <table class="table table-bordered" id="library-table">
                <thead>
                    <tr>
                        <th></th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Author</th>
                        <th>Filter</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
    <!-- /.row -->
    