@extends('layouts.master')
@section('content')

<!-- Main content -->
<section class="content">

    <div class="row">

        <div class="col-md-12">
            <div class="content body">

                <section id="introduction">
                    <h2 class="page-header"><a >Frequent Quesntions</a></h2>
                    <p class="lead">
                        <b>UnELeaP</b>

                    </p>


            </div>
        </div>
    </div>
</section>
@endsection