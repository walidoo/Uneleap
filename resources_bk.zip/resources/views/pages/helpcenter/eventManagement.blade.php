@extends('layouts.master')
@section('content')

<!-- Main content -->
<section class="content">

    <div class="row">

        <div class="col-md-12">
            <div class="content body">

                <section id="introduction">
                    <h2 class="page-header"><a >Event Management</a></h2>
                    <p class="lead">
                        <b>All Events</b>

                    </p>
                </section><!-- /#introduction -->
                <section id="license">
                    <h2 class="page-header"><a >My Events</a></h2>
                    <h3>Creating Events</h3>
                    <p class="lead">
                        
                    </p>
                </section>


            </div>
        </div>
    </div>
</section>
@endsection