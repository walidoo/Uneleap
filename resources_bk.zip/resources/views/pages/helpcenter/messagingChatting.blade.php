@extends('layouts.master')
@section('content')

<!-- Main content -->
<section class="content">

    <div class="row">

        <div class="col-md-12">
            <div class="content body">

                <section id="introduction">
                    <h2 class="page-header"><a >Messaging</a></h2>
                    <p class="lead">
                        <b>Chat Page</b> 
                    </p>
                </section><!-- /#introduction -->
                <section id="license">
                    <h2 class="page-header"><a >User chats</a></h2>
                    <h3>Notification</h3>
                    <p class="lead">
                
                    </p>
                </section>


            </div>
        </div>
    </div>
</section>
@endsection