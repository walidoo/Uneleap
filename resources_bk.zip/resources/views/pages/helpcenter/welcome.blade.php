@extends('layouts.master')
@section('content')

<!-- Main content -->
<section class="content">

    <div class="row">

        <div class="col-md-12">
            <div class="content body">

                <section id="introduction">
                    <h2 class="page-header"><a >Introduction</a></h2>
                    <p class="lead">
                        <b>UnELeaP</b>

                </section><!-- /#introduction -->
                <section id="license">
                    <h2 class="page-header"><a >Basic</a></h2>
                    <h3>Welcome</h3>
                    <p class="lead">
                       
                    </p>
                </section>


            </div>
        </div>
    </div>
</section>
@endsection