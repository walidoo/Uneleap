<select data-placeholder="Choose a Languages..." name="languages[]" class="chosen-select-languages form-control validate[required]" multiple  tabindex="4">

</select>
<script type="text/javascript">
    /*$(".chosen-select-courses").chosen();*/
    $('.chosen-select-languages').select2({
        tags: true
    })
</script>