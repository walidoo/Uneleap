Hi, {{ $name }}<br/>\t\n

Thank you for registering at \"UneLeap\". Your account is created and must be activated before you can use it.<br/>
To activate the account click on the following link or copy-paste it in your broswer
{{ url('user/activation', $link)}}